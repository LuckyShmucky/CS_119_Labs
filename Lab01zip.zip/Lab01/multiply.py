#!/user/bin/env python3

# Christian Luciano
# Cuyamaca College CS-119-0799
# Lab 1, exercise 1, multiply 2 numbers

# declare variables

number1 = 0
number2 = 0
number3 = 0

# input
number1 = int(input("Enter first number: "))
number2 = int(input("Entere second number: "))

# process
product = number1 * number2

# output
print("The product is " + str(product))
